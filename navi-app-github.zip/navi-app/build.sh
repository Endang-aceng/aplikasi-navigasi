#!/data/data/com.termux/files/usr/bin/bash
# Membangun navi.apk langsung di Termux. Tanpa Gradle, tanpa Android Studio.
# Pemakaian:  bash build.sh
set -e
cd "$(dirname "$0")"

say() { echo "$*"; }
gagal() { echo "GAGAL: $*"; exit 1; }

say "Langkah 1 dari 6. Memasang alat build."
pkg update -y >/dev/null 2>&1 || true
for p in openjdk-17 aapt aapt2 apksigner ecj dx zip; do
  pkg install -y "$p" >/dev/null 2>&1 || say "Peringatan: paket $p tidak terpasang."
done

for t in javac ecj aapt2 apksigner zip keytool; do
  command -v "$t" >/dev/null 2>&1 || gagal "perintah $t tidak ditemukan. Coba: pkg install $t"
done
if command -v d8 >/dev/null 2>&1; then DEXER=d8
elif command -v dx >/dev/null 2>&1; then DEXER=dx
else gagal "tidak ada d8 maupun dx. Coba: pkg install dx"; fi

say "Langkah 2 dari 6. Mencari android.jar."
AJ="${ANDROID_JAR:-}"
if [ -z "$AJ" ]; then
  for c in "$PREFIX/share/aapt/android.jar" "$PREFIX/share/android/android.jar" \
           "$HOME/android.jar" "$PWD/android.jar"; do
    [ -f "$c" ] && AJ="$c" && break
  done
fi
[ -z "$AJ" ] && AJ="$(find "$PREFIX" -name android.jar 2>/dev/null | head -n1)"
[ -f "$AJ" ] || gagal "android.jar tidak ditemukan. Taruh di folder ini, atau jalankan: ANDROID_JAR=/jalur/android.jar bash build.sh"
say "Memakai $AJ"

B=build
rm -rf "$B"; mkdir -p "$B/classes"

say "Langkah 3 dari 6. Mengompilasi Java."
ecj -source 8 -target 8 -nowarn -cp "$AJ" -d "$B/classes" $(find src -name '*.java')

say "Langkah 4 dari 6. Membuat classes.dex."
if [ "$DEXER" = d8 ]; then
  d8 --lib "$AJ" --min-api 24 --output "$B" $(find "$B/classes" -name '*.class')
else
  dx --dex --output="$B/classes.dex" "$B/classes"
fi
[ -f "$B/classes.dex" ] || gagal "classes.dex tidak terbentuk."

say "Langkah 5 dari 6. Membungkus APK."
aapt2 link -o "$B/navi.unsigned.apk" -I "$AJ" --manifest AndroidManifest.xml \
  --min-sdk-version 24 --target-sdk-version 28 --version-code 1 --version-name 1.0
( cd "$B" && zip -q -j navi.unsigned.apk classes.dex )

say "Langkah 6 dari 6. Menandatangani APK."
if [ ! -f navi.keystore ]; then
  keytool -genkeypair -keystore navi.keystore -alias navi -keyalg RSA -keysize 2048 \
    -validity 10000 -storepass navinavi -keypass navinavi -dname "CN=Navi" >/dev/null 2>&1
  say "Kunci tanda tangan baru dibuat: navi.keystore. Simpan file ini untuk pembaruan di masa depan."
fi
apksigner sign --ks navi.keystore --ks-pass pass:navinavi --key-pass pass:navinavi \
  --out navi.apk "$B/navi.unsigned.apk"
apksigner verify navi.apk >/dev/null || gagal "verifikasi tanda tangan gagal."

say "Selesai. File: $(pwd)/navi.apk"
if [ -d "$HOME/storage/downloads" ]; then
  cp navi.apk "$HOME/storage/downloads/navi.apk" && say "Salinan ada di folder Download."
else
  say "Agar bisa disalin ke folder Download, jalankan sekali: termux-setup-storage"
fi
say "Untuk memasang, jalankan: termux-open navi.apk"

package id.navi.app;

/** Satu langkah petunjuk arah. */
public final class Langkah {
    public String tipe = "";
    public String modifier = "";
    public String nama = "";
    public double jarak;        // meter menuju langkah berikutnya
    public double lat, lon;     // titik manuver
    public double arahAwal;     // derajat, untuk langkah "depart"
    public int keluar;          // nomor jalan keluar bundaran, 0 bila tidak ada
}

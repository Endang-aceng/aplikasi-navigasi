package id.navi.app;

/** Moda perjalanan beserta ambang pemanduannya. */
public final class Mode {
    public final String label;
    public final String layanan;   // nama layanan routing.openstreetmap.de
    public final String kataKerja;
    public final int dekat;        // meter: umumkan belokan berikutnya
    public final int sekarang;     // meter: umumkan "sekarang"
    public final int keluarRute;   // meter: dianggap keluar rute

    private Mode(String l, String s, String k, int d, int n, int x) {
        label = l; layanan = s; kataKerja = k; dekat = d; sekarang = n; keluarRute = x;
    }

    public static final Mode[] SEMUA = {
        new Mode("Jalan kaki", "routed-foot", "berjalan kaki", 40, 15, 40),
        new Mode("Sepeda", "routed-bike", "bersepeda", 80, 25, 50),
        new Mode("Motor", "routed-car", "bermotor", 150, 35, 60),
        new Mode("Mobil", "routed-car", "berkendara", 200, 40, 60),
    };
}

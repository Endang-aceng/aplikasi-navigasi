package id.navi.app;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.List;

/** Pencarian tempat (Nominatim) dan rute (OSRM) dari OpenStreetMap. Panggil dari thread latar. */
public final class OsmClient {
    private OsmClient() {}

    private static final String UA = "navi-android/1.0 (navigasi aksesibel)";
    private static final String NOMINATIM = "https://nominatim.openstreetmap.org";
    private static final String ROUTING = "https://routing.openstreetmap.de";

    public static final class Tempat {
        public String nama;
        public double lat, lon;
    }

    public static final class Rute {
        public double jarak, durasi;
        public List<Langkah> langkah = new ArrayList<Langkah>();
        public double[][] garis = new double[0][];
    }

    public static class GalatJaringan extends Exception {
        public GalatJaringan(String m) { super(m); }
    }

    private static String ambil(String alamat) throws GalatJaringan {
        String terakhir = "";
        for (int i = 0; i < 3; i++) {
            HttpURLConnection c = null;
            try {
                c = (HttpURLConnection) new URL(alamat).openConnection();
                c.setRequestProperty("User-Agent", UA);
                c.setConnectTimeout(15000);
                c.setReadTimeout(20000);
                int kode = c.getResponseCode();
                if (kode != 200) {
                    terakhir = "kode " + kode;
                } else {
                    InputStream in = c.getInputStream();
                    ByteArrayOutputStream out = new ByteArrayOutputStream();
                    byte[] buf = new byte[8192];
                    int n;
                    while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
                    in.close();
                    return out.toString("UTF-8");
                }
            } catch (IOException e) {
                terakhir = String.valueOf(e.getMessage());
            } finally {
                if (c != null) c.disconnect();
            }
            try { Thread.sleep(1500); } catch (InterruptedException ignored) { }
        }
        throw new GalatJaringan("Tidak bisa terhubung ke layanan peta. Periksa koneksi internet. (" + terakhir + ")");
    }

    public static String singkat(String nama) {
        String[] bagian = nama.split(",");
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < bagian.length && i < 3; i++) {
            if (i > 0) sb.append(", ");
            sb.append(bagian[i].trim());
        }
        return sb.toString();
    }

    /** Teks boleh berupa koordinat "lintang,bujur". */
    public static List<Tempat> cari(String teks) throws GalatJaringan {
        List<Tempat> hasil = new ArrayList<Tempat>();
        java.util.regex.Matcher m = java.util.regex.Pattern
                .compile("^\\s*(-?\\d+(?:\\.\\d+)?)\\s*,\\s*(-?\\d+(?:\\.\\d+)?)\\s*$").matcher(teks);
        if (m.matches()) {
            Tempat t = new Tempat();
            t.lat = Double.parseDouble(m.group(1));
            t.lon = Double.parseDouble(m.group(2));
            t.nama = "titik koordinat " + m.group(1) + ", " + m.group(2);
            hasil.add(t);
            return hasil;
        }
        try {
            String url = NOMINATIM + "/search?format=jsonv2&limit=5&accept-language=id&q="
                    + URLEncoder.encode(teks, "UTF-8");
            JSONArray arr = new JSONArray(ambil(url));
            for (int i = 0; i < arr.length(); i++) {
                JSONObject o = arr.getJSONObject(i);
                Tempat t = new Tempat();
                t.nama = singkat(o.getString("display_name"));
                t.lat = Double.parseDouble(o.getString("lat"));
                t.lon = Double.parseDouble(o.getString("lon"));
                hasil.add(t);
            }
        } catch (JSONException e) {
            throw new GalatJaringan("Jawaban layanan peta tidak bisa dibaca.");
        } catch (java.io.UnsupportedEncodingException e) {
            throw new GalatJaringan("Teks pencarian tidak valid.");
        }
        return hasil;
    }

    public static String namaLokasi(double lat, double lon) throws GalatJaringan {
        try {
            String url = NOMINATIM + "/reverse?format=jsonv2&zoom=18&accept-language=id&lat="
                    + lat + "&lon=" + lon;
            JSONObject o = new JSONObject(ambil(url));
            return o.has("display_name") ? singkat(o.getString("display_name")) : null;
        } catch (JSONException e) {
            return null;
        }
    }

    public static Rute rute(double laAsal, double loAsal, double laTuju, double loTuju, Mode mode)
            throws GalatJaringan {
        String url = ROUTING + "/" + mode.layanan + "/route/v1/driving/"
                + loAsal + "," + laAsal + ";" + loTuju + "," + laTuju
                + "?steps=true&overview=full&geometries=geojson";
        try {
            JSONObject d = new JSONObject(ambil(url));
            if (!"Ok".equals(d.optString("code")) || d.getJSONArray("routes").length() == 0) {
                throw new GalatJaringan("Rute tidak ditemukan antara dua titik itu untuk mode "
                        + mode.label.toLowerCase() + ".");
            }
            JSONObject r = d.getJSONArray("routes").getJSONObject(0);
            Rute hasil = new Rute();
            hasil.jarak = r.getDouble("distance");
            hasil.durasi = r.getDouble("duration");

            JSONArray koor = r.getJSONObject("geometry").getJSONArray("coordinates");
            hasil.garis = new double[koor.length()][2];
            for (int i = 0; i < koor.length(); i++) {
                JSONArray p = koor.getJSONArray(i);
                hasil.garis[i][0] = p.getDouble(0);
                hasil.garis[i][1] = p.getDouble(1);
            }

            JSONArray steps = r.getJSONArray("legs").getJSONObject(0).getJSONArray("steps");
            for (int i = 0; i < steps.length(); i++) {
                JSONObject s = steps.getJSONObject(i);
                JSONObject mv = s.getJSONObject("maneuver");
                Langkah l = new Langkah();
                l.tipe = mv.optString("type", "");
                l.modifier = mv.optString("modifier", "");
                l.nama = s.optString("name", "");
                l.jarak = s.optDouble("distance", 0);
                l.arahAwal = mv.optDouble("bearing_after", 0);
                l.keluar = mv.optInt("exit", 0);
                JSONArray loc = mv.getJSONArray("location");
                l.lon = loc.getDouble(0);
                l.lat = loc.getDouble(1);
                hasil.langkah.add(l);
            }
            if (hasil.langkah.isEmpty()) throw new GalatJaringan("Rute kosong.");
            return hasil;
        } catch (JSONException e) {
            throw new GalatJaringan("Jawaban layanan rute tidak bisa dibaca.");
        }
    }
}

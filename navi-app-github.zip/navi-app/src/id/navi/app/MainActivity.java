package id.navi.app;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.media.AudioAttributes;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.PowerManager;
import android.os.Vibrator;
import android.speech.tts.TextToSpeech;
import android.text.InputType;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.view.inputmethod.EditorInfo;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;

import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Layar tunggal yang dirancang untuk TalkBack: urutan fokus linear, semua kontrol
 * berlabel, tombol besar, hasil dalam kalimat utuh. Pemanduan memakai suara dan getar.
 */
public class MainActivity extends Activity implements TextToSpeech.OnInitListener, LocationListener {

    private interface Aksi { void jalan(OsmClient.Tempat t); }

    private final Handler utama = new Handler(Looper.getMainLooper());
    private final ExecutorService latar = Executors.newSingleThreadExecutor();

    private EditText kolomTujuan;
    private Spinner pilihMode;
    private TextView hasil;
    private ScrollView gulir;
    private Button tombolPandu, tombolBerhenti, tombolUlang;

    private TextToSpeech tts;
    private boolean ttsSiap = false;
    private LocationManager lm;
    private Vibrator getar;
    private PowerManager.WakeLock wake;

    // Status pemanduan
    private boolean aktif = false;
    private boolean menghitungUlang = false;
    private OsmClient.Rute rute;
    private OsmClient.Tempat tujuan;
    private Mode mode = Mode.SEMUA[0];
    private int k;
    private boolean sudahDekat;
    private int luarRute;
    private long terakhirLapor;
    private String kalimatTerakhir = "";

    // Permintaan lokasi sekali jalan
    private interface LokasiCb { void siap(Location l); void gagal(String pesan); }
    private LocationListener sekaliListener;
    private Runnable sekaliBatas;

    // ------------------------------------------------------------ UI

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        setTitle("Navi Navigasi");

        lm = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
        getar = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
        tts = new TextToSpeech(this, this);

        LinearLayout akar = new LinearLayout(this);
        akar.setOrientation(LinearLayout.VERTICAL);
        int p = dp(16);
        akar.setPadding(p, p, p, p);

        TextView judul = new TextView(this);
        judul.setText("Navi, navigasi perjalanan");
        judul.setTextSize(24);
        judul.setTypeface(null, android.graphics.Typeface.BOLD);
        judulKan(judul);
        akar.addView(judul);

        TextView labelTujuan = new TextView(this);
        labelTujuan.setText("Tujuan");
        labelTujuan.setTextSize(18);
        labelTujuan.setPadding(0, dp(12), 0, 0);
        akar.addView(labelTujuan);

        kolomTujuan = new EditText(this);
        kolomTujuan.setHint("Ketik nama tempat atau lintang koma bujur");
        kolomTujuan.setContentDescription("Tujuan. Ketik nama tempat atau koordinat.");
        kolomTujuan.setTextSize(20);
        kolomTujuan.setSingleLine(true);
        kolomTujuan.setInputType(InputType.TYPE_CLASS_TEXT);
        kolomTujuan.setImeOptions(EditorInfo.IME_ACTION_DONE);
        labelTujuan.setLabelFor(generateId(kolomTujuan));
        akar.addView(kolomTujuan, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        TextView labelMode = new TextView(this);
        labelMode.setText("Moda perjalanan");
        labelMode.setTextSize(18);
        labelMode.setPadding(0, dp(12), 0, 0);
        akar.addView(labelMode);

        pilihMode = new Spinner(this);
        String[] nama = new String[Mode.SEMUA.length];
        for (int i = 0; i < nama.length; i++) nama[i] = Mode.SEMUA[i].label;
        ArrayAdapter<String> ad = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, nama);
        ad.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        pilihMode.setAdapter(ad);
        pilihMode.setContentDescription("Moda perjalanan");
        pilihMode.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            public void onItemSelected(AdapterView<?> a, View v, int pos, long id) { mode = Mode.SEMUA[pos]; }
            public void onNothingSelected(AdapterView<?> a) { }
        });
        akar.addView(pilihMode);

        akar.addView(tombol("Di mana saya", new View.OnClickListener() {
            public void onClick(View v) { perintahLokasi(); }
        }));
        akar.addView(tombol("Arah ke tujuan", new View.OnClickListener() {
            public void onClick(View v) { perintahArah(); }
        }));
        akar.addView(tombol("Baca rute lengkap", new View.OnClickListener() {
            public void onClick(View v) { perintahRute(); }
        }));
        tombolPandu = tombol("Mulai pemanduan", new View.OnClickListener() {
            public void onClick(View v) { perintahPandu(); }
        });
        akar.addView(tombolPandu);
        tombolUlang = tombol("Ulangi instruksi terakhir", new View.OnClickListener() {
            public void onClick(View v) { if (kalimatTerakhir.length() > 0) ucap(kalimatTerakhir); }
        });
        tombolUlang.setEnabled(false);
        akar.addView(tombolUlang);
        tombolBerhenti = tombol("Berhenti", new View.OnClickListener() {
            public void onClick(View v) { berhenti(true); }
        });
        tombolBerhenti.setEnabled(false);
        akar.addView(tombolBerhenti);

        TextView labelHasil = new TextView(this);
        labelHasil.setText("Hasil");
        labelHasil.setTextSize(18);
        judulKan(labelHasil);
        labelHasil.setPadding(0, dp(16), 0, 0);
        akar.addView(labelHasil);

        hasil = new TextView(this);
        hasil.setTextSize(20);
        hasil.setTextIsSelectable(true);
        hasil.setFocusable(true);
        hasil.setText("Siap. Isi tujuan lalu pilih salah satu tombol.");
        akar.addView(hasil);

        gulir = new ScrollView(this);
        gulir.addView(akar);
        setContentView(gulir);

        mintaIzin();
    }

    private void judulKan(TextView t) {
        if (android.os.Build.VERSION.SDK_INT >= 28) t.setAccessibilityHeading(true);
    }

    private int generateId(View v) {
        int id = View.generateViewId();
        v.setId(id);
        return id;
    }

    private Button tombol(String teks, View.OnClickListener l) {
        Button t = new Button(this);
        t.setText(teks);
        t.setTextSize(20);
        t.setAllCaps(false);
        t.setMinHeight(dp(64));
        t.setOnClickListener(l);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.topMargin = dp(10);
        t.setLayoutParams(lp);
        return t;
    }

    private int dp(int n) {
        return (int) (n * getResources().getDisplayMetrics().density + 0.5f);
    }

    /** Tampilkan teks; untuk perintah sekali jalan, umumkan lewat pembaca layar. */
    private void tampil(final String teks, final boolean umumkan) {
        utama.post(new Runnable() {
            public void run() {
                hasil.setText(teks);
                if (umumkan) hasil.announceForAccessibility(teks);
            }
        });
    }

    private void tambah(final String baris) {
        utama.post(new Runnable() {
            public void run() {
                hasil.setText(hasil.getText() + "\n" + baris);
            }
        });
    }

    // ------------------------------------------------------ izin, suara

    private void mintaIzin() {
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, 1);
        }
    }

    @Override
    public void onRequestPermissionsResult(int req, String[] izin, int[] hasilIzin) {
        if (hasilIzin.length > 0 && hasilIzin[0] == PackageManager.PERMISSION_GRANTED) {
            tampil("Izin lokasi diberikan. Siap digunakan.", true);
        } else {
            tampil("Izin lokasi ditolak. Tanpa izin ini, aplikasi tidak bisa mengetahui posisi Anda. "
                    + "Buka pengaturan aplikasi untuk memberi izin.", true);
        }
    }

    private boolean punyaIzin() {
        return checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED;
    }

    @Override
    public void onInit(int status) {
        if (status != TextToSpeech.SUCCESS) return;
        int r = tts.setLanguage(new Locale("id", "ID"));
        ttsSiap = true;
        tts.setAudioAttributes(new AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_ASSISTANCE_NAVIGATION_GUIDANCE)
                .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build());
        if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) {
            tambah("Catatan: suara bahasa Indonesia belum terpasang di perangkat ini, memakai suara bawaan.");
        }
    }

    /** Ucapkan lewat TTS dan catat di layar. Dipakai pada mode pemanduan. */
    private void ucap(final String teks) {
        kalimatTerakhir = teks;
        utama.post(new Runnable() {
            public void run() {
                tombolUlang.setEnabled(true);
                hasil.setText(teks);
                if (ttsSiap) tts.speak(teks, TextToSpeech.QUEUE_ADD, null, "navi");
            }
        });
    }

    private void getarPola(String modifier, boolean tiba) {
        if (getar == null || !getar.hasVibrator()) return;
        if (tiba) getar.vibrate(new long[]{0, 600}, -1);
        else if (modifier.contains("left")) getar.vibrate(new long[]{0, 200}, -1);
        else if (modifier.contains("right")) getar.vibrate(new long[]{0, 200, 150, 200}, -1);
        else getar.vibrate(new long[]{0, 500}, -1);
    }

    // --------------------------------------------------------- lokasi

    private void lokasiSekali(final LokasiCb cb) {
        if (!punyaIzin()) { cb.gagal("Izin lokasi belum diberikan."); mintaIzin(); return; }
        boolean gps = lm.isProviderEnabled(LocationManager.GPS_PROVIDER);
        boolean jar = lm.isProviderEnabled(LocationManager.NETWORK_PROVIDER);
        if (!gps && !jar) {
            cb.gagal("Layanan lokasi mati. Nyalakan lokasi di pengaturan perangkat, lalu coba lagi.");
            return;
        }
        batalSekali();
        final boolean[] selesai = {false};
        sekaliListener = new LocationListener() {
            public void onLocationChanged(Location l) {
                if (selesai[0]) return;
                selesai[0] = true;
                batalSekali();
                cb.siap(l);
            }
            public void onStatusChanged(String p, int s, Bundle e) { }
            public void onProviderEnabled(String p) { }
            public void onProviderDisabled(String p) { }
        };
        try {
            if (gps) lm.requestLocationUpdates(LocationManager.GPS_PROVIDER, 0, 0, sekaliListener, Looper.getMainLooper());
            if (jar) lm.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 0, 0, sekaliListener, Looper.getMainLooper());
        } catch (SecurityException e) {
            cb.gagal("Izin lokasi belum diberikan.");
            return;
        }
        sekaliBatas = new Runnable() {
            public void run() {
                if (selesai[0]) return;
                selesai[0] = true;
                batalSekali();
                cb.gagal("Lokasi belum didapat. Pastikan GPS menyala, lalu coba lagi di tempat terbuka.");
            }
        };
        utama.postDelayed(sekaliBatas, 45000);
    }

    private void batalSekali() {
        if (sekaliBatas != null) { utama.removeCallbacks(sekaliBatas); sekaliBatas = null; }
        if (sekaliListener != null) {
            try { lm.removeUpdates(sekaliListener); } catch (SecurityException ignored) { }
            sekaliListener = null;
        }
    }

    // ------------------------------------------------------- perintah

    private String tujuanTeks() {
        return kolomTujuan.getText().toString().trim();
    }

    private void perintahLokasi() {
        tampil("Mencari lokasi Anda, mohon tunggu.", true);
        lokasiSekali(new LokasiCb() {
            public void siap(final Location l) {
                latar.execute(new Runnable() {
                    public void run() {
                        String nama = null;
                        try { nama = OsmClient.namaLokasi(l.getLatitude(), l.getLongitude()); }
                        catch (OsmClient.GalatJaringan ignored) { }
                        StringBuilder sb = new StringBuilder();
                        sb.append("Anda berada di ").append(nama != null ? nama : "lokasi yang namanya tidak diketahui").append(".");
                        if (l.hasAccuracy()) sb.append(" Ketelitian sekitar ").append(Geo.jarakTeks(l.getAccuracy())).append(".");
                        sb.append(String.format(Locale.US, " Koordinat lintang %.5f, bujur %.5f.", l.getLatitude(), l.getLongitude()));
                        tampil(sb.toString(), true);
                    }
                });
            }
            public void gagal(String pesan) { tampil(pesan, true); }
        });
    }

    /** Cari tujuan; bila ada beberapa hasil, minta pengguna memilih lewat dialog. */
    private void siapkanTujuan(final Aksi next) {
        final String q = tujuanTeks();
        if (q.length() == 0) { tampil("Tujuan masih kosong. Isi kolom tujuan terlebih dahulu.", true); return; }
        tampil("Mencari " + q + ".", true);
        latar.execute(new Runnable() {
            public void run() {
                try {
                    final List<OsmClient.Tempat> daftar = OsmClient.cari(q);
                    try { Thread.sleep(1000); } catch (InterruptedException ignored) { }
                    if (daftar.isEmpty()) {
                        tampil("Tempat \"" + q + "\" tidak ditemukan. Coba tulis lebih lengkap, misalnya tambahkan nama kota.", true);
                        return;
                    }
                    utama.post(new Runnable() {
                        public void run() {
                            if (daftar.size() == 1) { next.jalan(daftar.get(0)); return; }
                            String[] item = new String[daftar.size()];
                            for (int i = 0; i < item.length; i++) item[i] = (i + 1) + ". " + daftar.get(i).nama;
                            new AlertDialog.Builder(MainActivity.this)
                                    .setTitle("Ditemukan " + item.length + " tempat. Pilih salah satu.")
                                    .setItems(item, new DialogInterface.OnClickListener() {
                                        public void onClick(DialogInterface d, int which) { next.jalan(daftar.get(which)); }
                                    })
                                    .setNegativeButton("Batal", null)
                                    .show();
                        }
                    });
                } catch (OsmClient.GalatJaringan e) {
                    tampil("Kesalahan: " + e.getMessage(), true);
                }
            }
        });
    }

    private void perintahArah() {
        siapkanTujuan(new Aksi() {
            public void jalan(final OsmClient.Tempat t) {
                lokasiSekali(new LokasiCb() {
                    public void siap(Location l) {
                        double d = Geo.jarak(l.getLatitude(), l.getLongitude(), t.lat, t.lon);
                        double s = Geo.sudut(l.getLatitude(), l.getLongitude(), t.lat, t.lon);
                        tampil(t.nama + " berada di arah " + Geo.arahMata(s) + " dari posisi Anda, sekitar "
                                + Geo.jarakTeks(d) + " dalam garis lurus.", true);
                    }
                    public void gagal(String pesan) { tampil(pesan, true); }
                });
            }
        });
    }

    private void perintahRute() {
        final Mode m = mode;
        siapkanTujuan(new Aksi() {
            public void jalan(final OsmClient.Tempat t) {
                tampil("Mengambil lokasi Anda sebagai titik awal.", true);
                lokasiSekali(new LokasiCb() {
                    public void siap(final Location l) {
                        latar.execute(new Runnable() {
                            public void run() {
                                try {
                                    OsmClient.Rute r = OsmClient.rute(l.getLatitude(), l.getLongitude(), t.lat, t.lon, m);
                                    StringBuilder sb = new StringBuilder();
                                    sb.append("Rute dari lokasi Anda sekarang ke ").append(t.nama).append(".\n");
                                    sb.append("Jarak total ").append(Geo.jarakTeks(r.jarak)).append(", perkiraan ")
                                            .append(Geo.durasiTeks(r.durasi)).append(" ").append(m.kataKerja).append(".\n");
                                    int n = r.langkah.size();
                                    sb.append("Ada ").append(n).append(" langkah.\n");
                                    for (int i = 0; i < n; i++) {
                                        Langkah s = r.langkah.get(i);
                                        sb.append("Langkah ").append(i + 1).append(" dari ").append(n).append(". ")
                                                .append(Narasi.teks(s));
                                        if (!s.tipe.equals("arrive")) sb.append(", lalu lanjut ").append(Geo.jarakTeks(s.jarak));
                                        sb.append(".\n");
                                    }
                                    sb.append("Selesai.");
                                    tampil(sb.toString(), false);
                                    final String ringkas = "Rute siap. Jarak total " + Geo.jarakTeks(r.jarak)
                                            + ". Geser ke bagian hasil untuk membaca langkahnya.";
                                    utama.post(new Runnable() {
                                        public void run() { hasil.announceForAccessibility(ringkas); }
                                    });
                                } catch (OsmClient.GalatJaringan e) {
                                    tampil("Kesalahan: " + e.getMessage(), true);
                                }
                            }
                        });
                    }
                    public void gagal(String pesan) { tampil(pesan, true); }
                });
            }
        });
    }

    // ----------------------------------------------------- pemanduan

    private void perintahPandu() {
        if (aktif) { tampil("Pemanduan sedang berjalan. Pilih Berhenti untuk mengakhiri.", true); return; }
        final Mode m = mode;
        siapkanTujuan(new Aksi() {
            public void jalan(final OsmClient.Tempat t) {
                ucap("Tujuan: " + t.nama + ". Mengambil lokasi Anda.");
                lokasiSekali(new LokasiCb() {
                    public void siap(final Location l) {
                        latar.execute(new Runnable() {
                            public void run() {
                                try {
                                    final OsmClient.Rute r = OsmClient.rute(l.getLatitude(), l.getLongitude(), t.lat, t.lon, m);
                                    utama.post(new Runnable() {
                                        public void run() { mulaiPandu(t, m, r); }
                                    });
                                } catch (OsmClient.GalatJaringan e) {
                                    tampil("Kesalahan: " + e.getMessage(), true);
                                }
                            }
                        });
                    }
                    public void gagal(String pesan) { tampil(pesan, true); }
                });
            }
        });
    }

    private void mulaiPandu(OsmClient.Tempat t, Mode m, OsmClient.Rute r) {
        tujuan = t; mode = m; rute = r;
        k = 1; sudahDekat = false; luarRute = 0; menghitungUlang = false;
        terakhirLapor = System.currentTimeMillis();
        aktif = true;
        tombolPandu.setEnabled(false);
        tombolBerhenti.setEnabled(true);
        kolomTujuan.setEnabled(false);
        pilihMode.setEnabled(false);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
        wake = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "navi:pandu");
        wake.acquire(6 * 60 * 60 * 1000L);

        Langkah awal = r.langkah.get(0);
        ucap("Pemanduan dimulai. Jarak " + Geo.jarakTeks(r.jarak) + ", perkiraan " + Geo.durasiTeks(r.durasi)
                + " " + m.kataKerja + ". " + Narasi.teks(awal) + ", lalu lanjut " + Geo.jarakTeks(awal.jarak) + ".");
        try {
            lm.requestLocationUpdates(LocationManager.GPS_PROVIDER, 2000, 0, this, Looper.getMainLooper());
            if (lm.isProviderEnabled(LocationManager.NETWORK_PROVIDER)) {
                lm.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 4000, 0, this, Looper.getMainLooper());
            }
        } catch (SecurityException e) {
            berhenti(false);
            tampil("Izin lokasi belum diberikan.", true);
        }
    }

    private void berhenti(boolean umumkan) {
        boolean tadiAktif = aktif;
        aktif = false;
        try { lm.removeUpdates(this); } catch (SecurityException ignored) { }
        if (wake != null && wake.isHeld()) wake.release();
        getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        tombolPandu.setEnabled(true);
        tombolBerhenti.setEnabled(false);
        kolomTujuan.setEnabled(true);
        pilihMode.setEnabled(true);
        if (umumkan && tadiAktif) ucap("Pemanduan dihentikan.");
    }

    @Override
    public void onLocationChanged(Location l) {
        if (!aktif || rute == null || menghitungUlang) return;

        double lat = l.getLatitude(), lon = l.getLongitude();
        double akurasi = l.hasAccuracy() ? l.getAccuracy() : 0;

        // Keluar rute?
        double ambang = Math.max(mode.keluarRute, akurasi * 1.5);
        if (Geo.jarakKeGaris(lat, lon, rute.garis) > ambang) luarRute++; else luarRute = 0;
        if (luarRute >= 2) { hitungUlang(lat, lon); return; }

        if (k >= rute.langkah.size()) { selesai(); return; }
        Langkah s = rute.langkah.get(k);
        double d = Geo.jarak(lat, lon, s.lat, s.lon);

        if (s.tipe.equals("arrive")) {
            if (d <= mode.sekarang * 1.5) {
                ucap(Narasi.teks(s) + ".");
                getarPola(s.modifier, true);
                selesai();
                return;
            }
        } else if (d <= mode.sekarang) {
            String kal = "Sekarang, " + Narasi.huruf(Narasi.teks(s)) + ".";
            getarPola(s.modifier, false);
            double lanjut = s.jarak;
            k++;
            sudahDekat = false;
            if (k < rute.langkah.size() && lanjut > mode.dekat) kal += " Lanjut " + Geo.jarakTeks(lanjut) + ".";
            ucap(kal);
            terakhirLapor = System.currentTimeMillis();
            return;
        }

        if (!sudahDekat && d <= mode.dekat) {
            ucap("Dalam " + Geo.jarakTeks(d) + ": " + Narasi.teks(s) + ".");
            sudahDekat = true;
            terakhirLapor = System.currentTimeMillis();
        } else if (System.currentTimeMillis() - terakhirLapor >= 30000) {
            ucap("Langkah berikutnya dalam " + Geo.jarakTeks(d) + ".");
            terakhirLapor = System.currentTimeMillis();
        }
    }

    private void hitungUlang(final double lat, final double lon) {
        menghitungUlang = true;
        ucap("Anda keluar dari rute. Menghitung ulang.");
        latar.execute(new Runnable() {
            public void run() {
                try {
                    final OsmClient.Rute baru = OsmClient.rute(lat, lon, tujuan.lat, tujuan.lon, mode);
                    utama.post(new Runnable() {
                        public void run() {
                            if (!aktif) return;
                            rute = baru; k = 1; sudahDekat = false; luarRute = 0;
                            Langkah a = baru.langkah.get(0);
                            ucap("Rute baru. " + Narasi.teks(a) + ", lalu lanjut " + Geo.jarakTeks(a.jarak) + ".");
                            menghitungUlang = false;
                        }
                    });
                } catch (OsmClient.GalatJaringan e) {
                    utama.post(new Runnable() {
                        public void run() {
                            luarRute = 0;
                            menghitungUlang = false;
                            ucap("Gagal menghitung ulang. Periksa koneksi internet.");
                        }
                    });
                }
            }
        });
    }

    private void selesai() {
        berhenti(false);
        ucap("Pemanduan selesai.");
    }

    @Override public void onStatusChanged(String p, int s, Bundle e) { }
    @Override public void onProviderEnabled(String p) { }
    @Override public void onProviderDisabled(String p) { }

    @Override
    protected void onDestroy() {
        berhenti(false);
        batalSekali();
        latar.shutdownNow();
        if (tts != null) { tts.stop(); tts.shutdown(); }
        super.onDestroy();
    }
}

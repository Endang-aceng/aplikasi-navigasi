package id.navi.app;

/** Hitungan geografi dan pemformat teks. Murni Java, tanpa API Android. */
public final class Geo {
    private Geo() {}

    private static final String[] ARAH = {
        "utara", "timur laut", "timur", "tenggara",
        "selatan", "barat daya", "barat", "barat laut"
    };

    public static double jarak(double la1, double lo1, double la2, double lo2) {
        double r = 6371000.0;
        double p1 = Math.toRadians(la1), p2 = Math.toRadians(la2);
        double dp = p2 - p1, dl = Math.toRadians(lo2 - lo1);
        double h = Math.sin(dp / 2) * Math.sin(dp / 2)
                + Math.cos(p1) * Math.cos(p2) * Math.sin(dl / 2) * Math.sin(dl / 2);
        return 2 * r * Math.asin(Math.sqrt(h));
    }

    public static double sudut(double la1, double lo1, double la2, double lo2) {
        double p1 = Math.toRadians(la1), p2 = Math.toRadians(la2);
        double dl = Math.toRadians(lo2 - lo1);
        double y = Math.sin(dl) * Math.cos(p2);
        double x = Math.cos(p1) * Math.sin(p2) - Math.sin(p1) * Math.cos(p2) * Math.cos(dl);
        return (Math.toDegrees(Math.atan2(y, x)) + 360.0) % 360.0;
    }

    public static String arahMata(double derajat) {
        double d = ((derajat % 360.0) + 360.0) % 360.0;
        return ARAH[((int) ((d + 22.5) / 45.0)) % 8];
    }

    /** Jarak terdekat titik ke garis; garis[i] = {bujur, lintang}. */
    public static double jarakKeGaris(double lat, double lon, double[][] garis) {
        double kx = 111320.0 * Math.cos(Math.toRadians(lat));
        double ky = 110540.0;
        double terbaik = Double.MAX_VALUE;
        for (int i = 0; i + 1 < garis.length; i++) {
            double x1 = (garis[i][0] - lon) * kx, y1 = (garis[i][1] - lat) * ky;
            double x2 = (garis[i + 1][0] - lon) * kx, y2 = (garis[i + 1][1] - lat) * ky;
            double dx = x2 - x1, dy = y2 - y1;
            double kuad = dx * dx + dy * dy;
            double t = kuad == 0 ? 0 : Math.max(0, Math.min(1, -(x1 * dx + y1 * dy) / kuad));
            double d = Math.hypot(x1 + t * dx, y1 + t * dy);
            if (d < terbaik) terbaik = d;
        }
        return terbaik;
    }

    public static String jarakTeks(double m) {
        if (m < 1000) {
            long n = m >= 100 ? Math.round(m / 10.0) * 10 : Math.round(m);
            return Math.max(n, 1) + " meter";
        }
        return String.format(java.util.Locale.US, "%.1f", m / 1000.0).replace('.', ',') + " kilometer";
    }

    public static String durasiTeks(double detik) {
        long menit = Math.round(detik / 60.0);
        if (menit < 1) return "kurang dari satu menit";
        if (menit < 60) return menit + " menit";
        long jam = menit / 60, sisa = menit % 60;
        return jam + " jam" + (sisa > 0 ? " " + sisa + " menit" : "");
    }
}

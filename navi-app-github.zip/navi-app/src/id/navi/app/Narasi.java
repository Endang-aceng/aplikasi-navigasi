package id.navi.app;

/** Mengubah langkah menjadi kalimat bahasa Indonesia. Murni Java. */
public final class Narasi {
    private Narasi() {}

    private static String mod(String m) {
        if ("left".equals(m)) return "kiri";
        if ("right".equals(m)) return "kanan";
        if ("slight left".equals(m)) return "serong ke kiri";
        if ("slight right".equals(m)) return "serong ke kanan";
        if ("sharp left".equals(m)) return "tajam ke kiri";
        if ("sharp right".equals(m)) return "tajam ke kanan";
        if ("uturn".equals(m)) return "putar balik";
        return "lurus";
    }

    public static String teks(Langkah s) {
        String t = s.tipe, m = s.modifier;
        String ke = s.nama.length() > 0 ? " ke " + s.nama : "";

        if (t.equals("depart")) {
            return "Mulai perjalanan ke arah " + Geo.arahMata(s.arahAwal)
                    + (s.nama.length() > 0 ? ", menyusuri " + s.nama : "");
        }
        if (t.equals("arrive")) {
            if (m.endsWith("left")) return "Anda tiba di tujuan. Tujuan berada di sebelah kiri";
            if (m.endsWith("right")) return "Anda tiba di tujuan. Tujuan berada di sebelah kanan";
            return "Anda tiba di tujuan";
        }
        if (t.equals("roundabout") || t.equals("rotary") || t.equals("roundabout turn")) {
            if (s.keluar > 0) return "Masuk bundaran, ambil jalan keluar ke-" + s.keluar + ke;
            return "Masuk bundaran" + ke;
        }
        if (t.equals("exit roundabout") || t.equals("exit rotary")) {
            return "Keluar dari bundaran" + ke;
        }
        if (t.equals("turn")) {
            if (m.equals("straight")) return "Lanjut lurus" + ke;
            if (m.equals("uturn")) return "Putar balik" + ke;
            return "Belok " + mod(m) + ke;
        }
        if (t.equals("end of road")) return "Di ujung jalan, belok " + mod(m) + ke;
        if (t.equals("fork")) return "Di percabangan, ambil jalur " + mod(m) + ke;
        if (t.equals("merge")) return "Bergabung ke jalan" + ke;
        if (t.equals("on ramp")) return "Masuk jalur masuk" + ke;
        if (t.equals("off ramp")) return "Ambil jalan keluar" + ke;
        if (m.length() == 0 || m.equals("straight")) return "Lanjut lurus" + ke;
        return "Lanjut " + mod(m) + ke;
    }

    public static String huruf(String s) {
        return s.length() == 0 ? s : Character.toLowerCase(s.charAt(0)) + s.substring(1);
    }
}

# Navi, navigasi perjalanan untuk pengguna pembaca layar

Aplikasi Android mandiri. Setelah APK terpasang, Termux tidak diperlukan lagi.

## Membangun APK

Cara A, di Termux (di ponsel):
1. Salin folder ini ke Termux, lalu masuk ke folder tersebut.
2. Jalankan `bash build.sh`.
3. Pasang dengan `termux-open navi.apk`. Izinkan "pasang dari sumber ini" bila diminta.

Cara B, di GitHub (tanpa alat apa pun di ponsel):
1. Buat repositori baru, lalu unggah ISI folder ini (bukan folder navi-app-nya) ke root repositori. Folder `.github` harus berada di root.
2. Setiap push ke `main`/`master` otomatis membangun APK. Atau buka tab Actions, pilih "Build APK", klik "Run workflow".
3. Setelah selesai, buka run tersebut dan unduh artefak `navi-apk` (zip berisi navi.apk).
4. Untuk rilis: buat tag, misalnya `git tag v1.0 && git push origin v1.0`. APK akan terlampir otomatis di halaman Releases.

Tanda tangan tetap (agar APK bisa diperbarui di atas versi lama):
1. Di komputer/Termux: `base64 -w0 navi.keystore` (hasil dari build Termux, atau buat dengan keytool).
2. Di GitHub: Settings > Secrets and variables > Actions, tambahkan `NAVI_KEYSTORE_BASE64` (hasil base64), `NAVI_KS_PASS` (kata sandi), dan `NAVI_KS_ALIAS` (alias, biasanya `navi`).
Tanpa secret ini, build tetap berhasil tetapi memakai kunci sementara yang berbeda tiap kali.

Cara C, di komputer dengan Android SDK: atur ANDROID_HOME lalu `bash build-sdk.sh`.

## Memakai aplikasi
Buka Navi, beri izin lokasi, ketik tujuan, pilih moda, lalu:
- Di mana saya: menyebut posisi Anda.
- Arah ke tujuan: arah mata angin dan jarak lurus.
- Baca rute lengkap: seluruh langkah sebagai teks.
- Mulai pemanduan: suara dan getar (satu getar kiri, dua getar kanan, satu panjang saat tiba).

Catatan: layar dijaga tetap menyala selama pemanduan. Data peta dari OpenStreetMap, butuh internet.
Simpan `navi.keystore`: pembaruan aplikasi harus ditandatangani dengan kunci yang sama.

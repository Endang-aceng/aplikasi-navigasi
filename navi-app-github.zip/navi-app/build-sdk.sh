#!/usr/bin/env bash
# Build di komputer atau CI yang punya Android SDK (ANDROID_HOME) dan JDK 17+.
# Dipakai juga oleh .github/workflows/build.yml
#
# Variabel opsional:
#   NAVI_KEYSTORE   jalur keystore (default: navi.keystore di folder ini)
#   NAVI_KS_PASS    kata sandi keystore dan kunci (default: navinavi)
#   NAVI_KS_ALIAS   alias kunci (default: navi)
#   NAVI_VERSION_CODE / NAVI_VERSION_NAME  versi aplikasi (default: 1 / 1.0)
set -euo pipefail
cd "$(dirname "$0")"

SDK="${ANDROID_HOME:-${ANDROID_SDK_ROOT:-}}"
[ -d "$SDK" ] || { echo "GAGAL: ANDROID_HOME belum diatur."; exit 1; }

# Hanya platform bernomor (abaikan android-Baklava, android-36-ext, dan sejenisnya).
BT="$(ls -d "$SDK"/build-tools/[0-9]* 2>/dev/null | sort -V | tail -n1)"
PLAT="$(ls -d "$SDK"/platforms/android-[0-9]* 2>/dev/null | grep -E 'android-[0-9]+$' | sort -V | tail -n1)"
[ -n "$BT" ]   || { echo "GAGAL: build-tools tidak ditemukan di $SDK"; exit 1; }
[ -n "$PLAT" ] || { echo "GAGAL: platform Android tidak ditemukan di $SDK"; exit 1; }
AJ="$PLAT/android.jar"
[ -f "$AJ" ] || { echo "GAGAL: $AJ tidak ada."; exit 1; }
echo "build-tools: $BT"; echo "android.jar: $AJ"

VC="${NAVI_VERSION_CODE:-1}"
VN="${NAVI_VERSION_NAME:-1.0}"
KS="${NAVI_KEYSTORE:-navi.keystore}"
KPASS="${NAVI_KS_PASS:-navinavi}"
KALIAS="${NAVI_KS_ALIAS:-navi}"

B=build; rm -rf "$B"; mkdir -p "$B/classes"
javac --release 8 -Xlint:-options -nowarn -encoding UTF-8 -cp "$AJ" -d "$B/classes" $(find src -name '*.java')
"$BT/d8" --lib "$AJ" --min-api 24 --output "$B" $(find "$B/classes" -name '*.class')
[ -f "$B/classes.dex" ] || { echo "GAGAL: classes.dex tidak terbentuk."; exit 1; }
"$BT/aapt2" link -o "$B/navi.unsigned.apk" -I "$AJ" --manifest AndroidManifest.xml \
  --min-sdk-version 24 --target-sdk-version 28 --version-code "$VC" --version-name "$VN"
( cd "$B" && zip -q -j navi.unsigned.apk classes.dex )
"$BT/zipalign" -f 4 "$B/navi.unsigned.apk" "$B/navi.aligned.apk"

if [ ! -f "$KS" ]; then
  echo "Membuat keystore baru: $KS"
  keytool -genkeypair -keystore "$KS" -alias "$KALIAS" -keyalg RSA -keysize 2048 \
    -validity 10000 -storepass "$KPASS" -keypass "$KPASS" -dname "CN=Navi" >/dev/null 2>&1
fi
"$BT/apksigner" sign --ks "$KS" --ks-key-alias "$KALIAS" --ks-pass "pass:$KPASS" --key-pass "pass:$KPASS" \
  --out navi.apk "$B/navi.aligned.apk"
"$BT/apksigner" verify navi.apk
echo "Selesai: $(pwd)/navi.apk"
